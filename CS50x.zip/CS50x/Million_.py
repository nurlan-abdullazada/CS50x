class Million:
    
    def __init__(self,bank_xidmetleri = "Bank Xidmetleri : ", kommunal_odenisler = "Kommunal Odenisler", sebeke_sistemleri = "Sebeke Sistemleri" ):
        self.bank_xidmetleri = bank_xidmetleri
        self.kommunal_odenisler = kommunal_odenisler
        self.sebeke_sistemleri = sebeke_sistemleri

    def choosesection(self):
        
        print("""
            Choose Section :
            1. Bank Xidmetleri
            2. Kommunal Odenisler
            3. Sebeke Sistemleri
        """)

        c = int(input("Choose Section : "))

        if c == 1:
            print("Bank Xidmetleri")
        
        elif c == 2:
            print("Kommunal Odenisler")

        elif c == 3:
            print("Sebeke Sistemleri")

        else:
            print("Incorrect choose")