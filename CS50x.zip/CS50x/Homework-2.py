for i in range(1,11):
    for k in range (1,11):
        print(i, "*", k, " = ", k*i)
        

# for i in range (1,101):
#     if(i%3 == 0):
#         print(i)