import Room.Resuscitation_room
import Room.Patient_room


class Patient_Condition:

    def patientCondition(self):

        print("-----------------------------------------")
        print("|Patient's condition is good = 1 	\n|Patient's condition isn't good = 2")
        print("-----------------------------------------")

        patient_condition = int(input("Patient condition: "))

        if patient_condition == 1:
            print("Patient can go patient room, there is nothing to worry about")
            pr=Room.Patient_room.Patient_room()
            pr.patientRoom()


        elif patient_condition == 2:
            print("Patient must go resuscitation room")


            print("------THEN------")
            print("-----------------------------------------")
            print("|Patient's condition is good = 1 	\n|Patient's condition isn't good = 2")
            print("-----------------------------------------")

            patient_condition_2 = int(input("Patient condition_2: "))

            if patient_condition_2 == 1:
                print("Patient can go patient room, there is nothing to worry about")
                pr = Room.Patient_room.Patient_room()
                pr.patientRoom()

            elif patient_condition_2 == 2:
                print("Patient must stay resuscitation room")

                print("------THENNN------")
                print("-----------------------------------------")
                print("|Patient's condition is good = 1 	\n|Patient's condition isn't good = 2")
                print("-----------------------------------------")

                patient_condition_3 = int(input("Patient condition_2: "))


                if patient_condition_3 == 1:
                    print("Patient can go home")

                elif patient_condition_3 == 2:
                    print("Başınız sağ olsun...")

                else :
                    print("Please Enter a correct choice")

        else :
            print("Please Enter a correct choice")