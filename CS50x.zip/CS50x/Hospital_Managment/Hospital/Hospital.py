class Hospital:

    print("********************************************************************")
    print("*                                                                  *")
    print("*             Welcome to Hospital Management System                *")
    print("*                                                                  *")
    print("********************************************************************")

    def __init__(self, hospital_name = None, hospital_departament = None, hospital_room = None, hospital_enterance = None):
        self.hospital_name = hospital_name
        self.hospital_staff = hospital_departament
        self.hospital_room = hospital_room
        self.hospital_enterance = hospital_enterance


