import Patient.Patient_condition
from Room.Rooms import Rooms
class Surgery_Room(Rooms):

    def __init__(self, name=None):
        Rooms.__init__(self, name)

    def surgeryRoom(self):

        print("-----------------------------------------")
        print("|Not Full = 1 	|\n|Full = 2")
        print("-----------------------------------------")

        surgery_room = int(input("Surgery Room : "))

        if surgery_room == 1:
            print("Prepare the surgery room")
            p = Patient.Patient_condition.Patient_Condition()
            p.patientCondition()

        elif surgery_room == 2:
            print("Prepare another surgery room")
            p = Patient.Patient_condition.Patient_Condition()
            p.patientCondition()

        else:
            print("Please Enter a correct choice")