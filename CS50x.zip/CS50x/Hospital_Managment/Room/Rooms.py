class Rooms:
    def __init__(self, name=None):
        self.name = name

    def chooseRoom(self):

        print("-----------------------------------------")
        print("|Surgery Room = 1 	|\n|Patient Room = 2    |\n|Rontgen Room = 3")
        print("-----------------------------------------")

        room = int(input("Choose Room : "))

        if room == 1:
            print("Go to surgery room")

        elif room == 2:
            print("Go to patient room")

        elif room == 3:
            print("Go to rontgen room")

        else:
            print("Please Enter a correct choice")