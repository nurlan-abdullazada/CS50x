from Room.Rooms import Rooms

class Intensive_Care_Unit(Rooms): #reanimasiya

    def __init__(self, name=None):
        Rooms.__init__(self, name)

    def patientCondition(self):

        print("-----------------------------------------")
        print("|Patient's condition is good = 1 	|\n|Patient's condition isn't good = 2")
        print("-----------------------------------------")

        patient_condition = int(input("Patient's condition"))

        if patient_condition == 1:
            print("The patient is transferred to the ward")

        elif patient_condition == 2:
            print("The patient must stay resuscitated for a while")

        else:
            print("Please Enter a correct choice")