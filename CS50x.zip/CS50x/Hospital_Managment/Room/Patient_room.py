from Room.Rooms import Rooms

class Patient_room(Rooms):
    def __init__(self, name=None):
        Rooms.__init__(self, name)

    def patientRoom(self):

        print("-----------------------------------------")
        print("|Not Full = 1 	|\n|Full = 2")
        print("-----------------------------------------")

        patient_room = 0

        try:
            patient_room = int(input("Patient Room : "))
        except:
            print("")

        if patient_room == 1:
            print("Prepare the patient room")

        elif patient_room == 2:
            print("Prepare another patient room")

        else:
            print("Please Enter a correct choice")