from Room.Rooms import Rooms


class Rontgen_Room(Rooms):
    def __init__(self, name=None):
        Rooms.__init__(self, name)


    def rentRoom(self):

        print("-----------------------------------------")
        print("|İf the part to be rontgen is the head area = 1   	|\n|İf the part to be rontgen is the body area = 2    |\n|İf the part to be rontgen is the foot area = 3")
        print("-----------------------------------------")

        rontgen_room = int(input("Enter your rontgen area : "))

        if rontgen_room == 1:
            print("Take paper of rontgen and approach the Surgery department")

        elif rontgen_room == 2:
            print("Take paper of rontgen and approach the Surgery department")

        elif rontgen_room == 3:
            print("Take paper of rontgen and approach the Surgery department")

        else:
            print("Please Enter a correct choice")
