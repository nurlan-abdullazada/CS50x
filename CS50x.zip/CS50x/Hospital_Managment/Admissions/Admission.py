import json

class Admission:

    def __init__(self, name= None, surname =None, age =None, gender =None, address =None):
        self.name = name
        self.surname = surname
        self.age = age
        self.gender = gender
        self.address = address
        self.serialize()

    def __str__(self):
        return f"{self.name} {self.surname} {self.age} {self.gender} {self.address}"

    def serialize(self):
        return {
            'name': self.name,
            'surname': self.surname,
            'age': self.age,
            'gender': self.gender,
            'address': self.address
        }

    def to_json(self):
        try:
            with open("admissions.json", 'r+') as f:
                arr = json.load(f)
                for i in arr:
                    if i['name'] == self.name and i['surname'] == self.surname and i['age'] == self.age and i['gender'] == self.gender and i['address'] == self.address :
                        return "\nPatient already exists"
                f.seek(0)
                arr.append(self.serialize())
                json.dump(arr, f)
        except:
            with open("admissions.json", 'w') as f:
                json.dump([self.serialize()], f)
        return "\nPatient added"