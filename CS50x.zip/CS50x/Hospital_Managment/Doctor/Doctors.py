def Write_Doctors_DataBase (Doctors_DataBase) :
	myfile = open("Doctors_DataBase.csv","w")
	for i in Doctors_DataBase :
		myfile.write(str(i)+";")
		for j in Doctors_DataBase[i] :
			myfile.write(str(j[0])+";"+j[1]+";"+j[2]+";")
		myfile.write("\n")
	myfile.close()