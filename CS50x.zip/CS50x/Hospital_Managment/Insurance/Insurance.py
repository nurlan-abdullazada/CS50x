from Admissions.Admission import Admission

class Insurance(Admission):
    def __init__(self, name=None, surname=None, age=None, gender=None, address=None):
        Admission.__init__(self, name, surname, age, gender, address)

    def patientInsurance(self):

        print("-----------------------------------------")
        print("|If you have insurance = 1 	\n|If you don't have insurance = 2")
        print("-----------------------------------------")

        insurance = int(input("Do you have insurance? : "))

        if insurance == 1:
            print("Patient can be treated for free")

        elif insurance == 2:
            print("Patient can't be treated for free")

            print("-----------------------------------------")
            print("|If you want insurance = 1 	\n|If you don't want insurance = 2")
            print("-----------------------------------------")

            insurance_want = int(input("Choose wants: "))

            if insurance_want == 1:
                print("Prepare insurance for patient")
                print("-------------------------------")
                print("Patient can be treated for free")

            elif insurance_want == 2:
                print("Patient can't be treated for free")

        else:
            print("Please Enter a correct choice")