from Departments.Hospital_Departaments import Department
import Room.Surgery_room
class Cardiology(Department):
    def __init__(self, name=None):
        Department.__init__(self, name)


    def heart_vein(self):

        print("-----------------------------------------")
        print("|Patient's heart is good = 1 	\n|Patient's heart isn't good = 2")
        print("-----------------------------------------")

        heart_vein = int(input("Patient heart: "))

        if heart_vein == 1:
            print("Patient can go home, there is nothing to worry about")

        elif heart_vein == 2:
            print("Patient have illness in heart and must be operated")


            print("-----------------------------------------")
            print("|A stent must be placed in the heart = 1 			\n|A new heart must be implanted = 2")
            print("-----------------------------------------")

            heart_check=int(input("Result check: "))

            if heart_check == 1:
                print("Prepare surgery room")
                s = Room.Surgery_room.Surgery_Room()
                s.surgeryRoom()

            elif heart_check == 2:
                print("Must be find donor")


            else :
                print("Please Enter a correct choice")

        else:
            print("Please Enter a correct choice")