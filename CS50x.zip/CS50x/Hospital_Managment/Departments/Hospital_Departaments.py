class Department:
    def __init__(self,name=None):
        self.name = name


    def chooseDepartament(self):

        print("-----------------------------------------")
        print("|Cardiology Departament = 1      \n|Neurology Departament = 2      \n|General_Surgery = 3")
        print("-----------------------------------------")










