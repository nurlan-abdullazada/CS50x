import Room.Surgery_room
import Room.Rontgen_room
from Departments.Hospital_Departaments import Department

class General_Surgery(Department):
    def __init__(self, name=None):
        Department.__init__(self, name)

    def surgeryOpareted(self):

        ro = Room.Rontgen_room.Rontgen_Room()
        ro.rentRoom()

        print("-----------------------------------------")
        print("|If the illness is in the head area = 1 			\n|If the illness is in the body area = 2  			\n|If the illness is in the foot area = 3 ")
        print("-----------------------------------------")


        surgery = int(input("Surgery result : "))

        if surgery == 1:
            print("Check patient's head")


            print("-----------------------------------------")
            print("|Condition is good = 1 			\n|Condition is not good = 2")
            print("-----------------------------------------")

            condition = int(input("Patient condition: "))

            if condition == 1:
                print("Patient can go home, there is nothing to worry about")

            elif condition == 2:
                print("Patient have illness must be operated")
                s=Room.Surgery_room.Surgery_Room()
                s.surgeryRoom()

            else :
                print("Please Enter a correct choice")

        elif surgery == 2:
            print("Check patient's body")

            print("-----------------------------------------")
            print("|Condition is good = 1 			\n|Condition is not good = 2")
            print("-----------------------------------------")

            condition = int(input("Patient condition: "))

            if condition == 1:
                print("Patient can go home, there is nothing to worry about")

            elif condition == 2:
                print("Patient have illness must be operated")
                s = Room.Surgery_room.Surgery_Room()
                s.surgeryRoom()

            else:
                print("Please Enter a correct choice")

        elif surgery == 3:
            print("Check patient's foot")

            print("-----------------------------------------")
            print("|Condition is good = 1 			\n|Condition is not good = 2")
            print("-----------------------------------------")

            condition = int(input("Patient condition: "))

            if condition == 1:
                print("Patient can go home, there is nothing to worry about")

            elif condition == 2:
                print("Patient have illness must be operated")
                s = Room.Surgery_room.Surgery_Room()
                s.surgeryRoom()

            else:
                print("Please Enter a correct choice")