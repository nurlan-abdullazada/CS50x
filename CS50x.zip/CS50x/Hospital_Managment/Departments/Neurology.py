from Departments.Hospital_Departaments import Department

class Neurology(Department):

    def __init__(self, name=None,salary=None):
        Department.__init__(self, name)
        self.salary = salary

    def mental_degree(self):

        print("-----------------------------------------")
        print("|If patient's mental degree is very bad = 1			\n|If patient's mental degree is normal = 2 			\n|If patient's mental degree is very good = 3")
        print("-----------------------------------------")

        mental_degree=int(input("Patient's mental degree: "))

        if mental_degree==1:
            print("The patient must be transferred to a mental hospital ")

        elif mental_degree==2:
            print("The patient must be treated  with money by a psychologist  in the hospital..")

        elif mental_degree==3:
            print("The patient can go home")

        else :
            print("Please Enter a correct choice")