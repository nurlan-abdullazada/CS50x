# list = [1,2,3,4]
# tuple(1,2,3,4)
# dict = {'Nurlan' : 13, 'Anar':10}



    