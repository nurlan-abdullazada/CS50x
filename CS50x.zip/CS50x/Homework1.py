import math
# a = int(input("kvadratin terefini daxil edin : " ))
    # s => sahe
# s = a*a
# print ("<< Kvadratin sahesi :", s,"' dir >>" )


# a = int(input("ucbucaqin terefini daxil edin : " ))
# b = int(input("ucbucaqin terefini daxil edin : " ))
# c = math.sqrt(a**2 + b**2)
# print("<< Duzbucaqli hipetonuzun uzunlugu",c,"dir >>")


# a = input("Adinizi daxil edin : " )
# b = int(input("Yasinizi daxil edin : " ))
# print(f"<< Menim adim {a}dir, menim 5 ilden sonra {b+5} yasim olacaq >>" )