class Bank_Xidmetleri(Million):
    
    def __init__(self, kapital_bank = ):
        