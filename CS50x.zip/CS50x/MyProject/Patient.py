class Patient:

    def __init__(self, name, surname, age, gender ):
        self.name = name
        self.surname = surname
        self.age = age
        self.gender = gender

    def getName(self):
        return self.name

    def getSurname(self):
        return self.surname

    def getAge(self):
        return self.age

    def getGender(self):
        return self.gender

    # def getIllness(self):
    #     return self.illness


    def patient_condition(self):

        print("""
            Patient's condition :
            1. Good = 1 click
            2. Not good = 2 click
        """)

        p = int(input("Patient's condition"))

        if p == 1:
            print("Let the patient go home")

        elif p == 2:
            print("The patient should stay here for a while")

        else:
            print("Incorrect information")



