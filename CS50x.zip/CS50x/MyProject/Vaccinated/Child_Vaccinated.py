from Vaccinated import Vaccinated


class Child_Vaccinated(Vaccinated):
    def __init__(self, name, quantity, number, age):
        Vaccinated.__init__(self, name,  quantity, number,)
        self.age = age

    def childVaccinated_age(self):
        a = int(input("Enter your age : "))
        if a > 6:
            print("Vaccination age is over")

        else:
            print("Must be vaccinated")