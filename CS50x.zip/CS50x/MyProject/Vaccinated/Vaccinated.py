class Vaccinated:
    def __init__(self, name=None, quantity=None, number=None):
        self.name = name
        self.quantity = quantity
        self.number = number

    def chooseVaccin(self):

        print("""
            Choose Vaccinated :
            1. Covid_Vaccinated = 1 click
            2. Child_Vaccinated = 2 click 
        """)

        c = int(input("Choose Departament : "))

        if c == 1:
            print("Covid_Vaccinated")

        elif c == 2:
            print("Child_Vaccinated")

        else:
            print("Something went wrong")









