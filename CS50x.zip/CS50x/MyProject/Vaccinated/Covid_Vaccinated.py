from Vaccinated.Vaccinated import Vaccinated


class Covid_Vaccinated(Vaccinated):

    def __init__(self, name, quantity, number, age):
        Vaccinated.__init__(self, name, quantity, number)
        self.age = age

    def covidVaccinated_age(self):
        a = int(input("Enter your age : "))

        if a >= 16:
            print("You can be vaccinated then you can enter inside hospital")

        else:
            print("Something went wrong")

    def chechealthstatus(self):

        print("""
            Do you have any allergies :
            1. Yes = 1 click
            2. No = 2 click

        """)
        c = int(input("Do you have any allergies? : "))

        if c == 1:
            print("You can't be vaccinated")

        elif c == 2:
            print("You can be vaccinated then you can enter inside hospital")

        else:
            print("Something went wrong")
