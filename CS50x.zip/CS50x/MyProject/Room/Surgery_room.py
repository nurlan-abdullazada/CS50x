from Room.Room import Room

class Surgery_room(Room):

    def __init__(self, name, locaion):
        Room.__init__(self, name, locaion)

    def surgeryRoom(self):

        print("""
            Surgery Room : 
            1. Not Full = 1 click
            2. Full = 2 click
        """)

        f = int(input("Surgery Room : "))

        if f == 1:
            print("Prepare the surgery room")

        elif f == 2:
            print("Prepare another surgery room")

        else:
            print("Incorrect Information")
