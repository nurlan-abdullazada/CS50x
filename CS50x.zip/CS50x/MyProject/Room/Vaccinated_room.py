from Room import Room

class Vaccinated_room(Room):
    def __init__(self, name, locaion):
        Room.__init__(self, name, locaion)

    def vaccianRoom(self):

        print("""
            Vaccinated Room : 
            1. Not Full = 1 click
            2. Full = 2 click
        """)

        v = int(input("Vaccinated Room : "))

        if v == 1:
            print("Prepare the vaccinated room")

        elif v == 2:
            print("Prepare another vaccinated room")

        else:
            print("Incorrect Information")
