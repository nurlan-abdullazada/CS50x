from Room import Room

class Laboratory_room(Room):
    def __init__(self, name, locaion):
        Room.__init__(self, name, locaion)

    def labRoom(self):

        print("""
            Laboratory Room : 
            1. Not Full = 1 click
            2. Full = 2 click
        """)

        l = int(input("Laboratory Room : "))

        if l == 1:
            print("This laboratory room is fully ready")

        elif l == 2:
            print("This laboratory room isn't fully ready")

        else:
            print("İncorrect İnformation")

