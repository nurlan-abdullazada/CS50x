from Room.Room import Room

class Checked_room(Room):

    def __init__(self, name, locaion):
        Room.__init__(self, name, locaion)

    def checkedRoom(self):

        print("""
            The result of the checkup : 
            1. Good = 1 click
            2. Not Good = 2 click
        """)
        a = input("The result of the checkup : ")

        if a == 1:
            print("There is no problem with your health")

        elif a == 2:
            print("You have a health problem and need treatment")

            print("""
                Your disease : 
                1. Organ Problem = 1 click
                2. Anemia Problem = 2 click
            """)
            a = input("Your disease : ")

            if a == 1:
                print("Approach the organ department")

            elif a == 2:
                print("You approach the blood department")

