import Room

class Patient_room(Room):
    def __init__(self, name, locaion):
        Room.__init__(self, name, locaion)

    def patientRoom(self):
        print("""
            Patient Room : 
            1. Not Full = 1 click
            2. Full = 2 click
        """)
        p = 0
        try:
            p = int(input("Patient Room : "))
        except:
            print("ge")
        if p == 1:
            print("Prepare the patient room")

        elif p == 2:
            print("Prepare another patient room")

        else:
            print("Incorrect Information")