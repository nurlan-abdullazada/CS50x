class Room:
    def __init__(self, name, location):
        self.name = name
        self.location = location

    def chooseRoom(self):

        print("""
            Choose Room :
            1. Surgery = 1 click
            2. Checked = 2 click
            3. Patient = 3 click
            4. Rentgen = 4 click
            5. Vaccinated = 5 click
            6. Laboratory = 6 click
        """)

        c = int(input("Choose Room : "))

        if c == 1:
            print("Surgery room")

        elif c == 2:
            print("Checked room")

        elif c == 3:
            print("Patinet room")

        elif c == 4:
            print("Rentgen room")

        elif c == 5:
            print("Vaccinated room")

        elif c == 6:
            print("Laboratory room")

        else:
            print("Incorrect choose")












