from Room import Room

class Rentgen_room(Room):
    def __init__(self, name, locaion):
        Room.__init__(self, name, locaion)


    def rentRoom(self):

        print("""
            If the illness is in the head area = 1 click
            If the illness is in the body area = 2 click
            If the illness is in the foot area = 3 click
        """)
        a = int(input("Enter your pain : "))

        if a == 1:
            print("Approach the surgical department")

        elif a == 2:
            print("Approach the surgical department")

        elif a == 3:
            print("Approach the surgical department")
