from Surgery import Surgery

class Injury(Surgery):

    def __init__(self, surgery_name, surgery_time):
        Surgery.__init__(self, surgery_name, surgery_time)

    def injurySurgery(self):

        print("""
            The patient's condition :
            1. Good = 1 click
            2. Not Good = 2 click
        """)
        a = int(input("The patient's condition : "))

        if a == 1:
            print("The patient's condition is good")

        elif a == 2:
            print("The patient isn't in good condition and should be taken to the intensive care unit")

        else:
            print("Patient died...")