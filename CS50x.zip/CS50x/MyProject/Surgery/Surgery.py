class Surgery:
    def __init__(self, surgery_name=None, surgery_time=None):
        self.surgery_name = surgery_name
        self.surgery_time = surgery_time

    def chooseSurgary(self):

        print("""
            Choose Surgery :
            1. Organ_Transfer = 1 click
            2. Injury = 2 click
            3. Blood_Transfer = 3 click
        """)

        c = int(input("Choose Surgery : "))

        if c == 1:
            print("Organ_Transfer")

        elif c == 2:
            print("Injury")

        elif c == 3:
            print("Blood_Transfer")

        else:
            print("Incorrect choose")






