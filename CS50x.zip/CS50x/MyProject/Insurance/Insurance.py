class Insurance:

    def __init__(self, Insurer, Insured):
        self.Insurer = Insurer
        self.Insured = Insured

    def getInsurer(self):
        return self.Insurer

    def getInsured(self):
        return self.Insured

    def setInsured(self, Insured):
        self.Insured = Insured


