class Patient_Insurance:
    def __init__(self, name, surname, age, amount_paid):
        self.name = name
        self.surname = surname
        self.age = age
        self.amount_paid = amount_paid

    def patientInsurance(self):
        print("""
                1. if you have insurance = 1 click
                2 . If you do not have insurance = 2 click

         """)

        a = int(input("Do you have insurance? : "))

        if a == 1:
            print("You can be treated for free")

        elif a == 2:
            print("You can't be treated for free")

        else:
            print("How else can we help ")

