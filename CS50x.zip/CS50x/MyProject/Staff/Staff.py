class Staff:

    def __init__(self, name=None, surname=None, work=None, working_time=None, salary=None):
        self.name = name
        self.surname = surname
        self.work = work
        self.working_time = working_time
        self.salary = salary



    def chooseStaff(self):

        print("""
            Choose Staff :
            1. Doctor = 1 click
            2. Security_Guard = 2 click
            3. Maid = 3 click
            4. Nurses = 4 click
        """)

        c = int(input("Choose Staff : "))

        if c == 1:
            print("Doctor")

        elif c == 2:
            print("Security_Guard")

        elif c == 3:
            print("Maid")

        elif c == 4:
            print("Nurses")

        else:
            print("Incorrect choose")










