class Salary_cleaner:
    def __init__(self, salary):
        self.salary = salary

    def total_salary(self):
        return (self.salary * 12)