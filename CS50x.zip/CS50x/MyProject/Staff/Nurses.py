from Staff.Staff import Staff
from Staff.Salary import Salary_cleaner

class Nurses(Staff):

    def __init__(self, name, surname, work, working_time, salary):
        Staff.__init__(self, name, surname, work, working_time, salary)

        self.salary = salary
        self.obj_salary = Salary_cleaner(salary)

    def total_salary(self):
        return (self.salary * 12)


    def getNursesName(self):
        return self.name

    def getNursesSurname(self):
        return self.surname

    def getNursesWork(self):
        return self.work

    def getNursesWorking_time(self):
        return self.working_time

    def getNursesSalary(self):
        return self.salary