from Staff import Staff
from Staff.Salary import Salary_cleaner

class Maid(Staff):

    def __init__(self, name, surname, work, working_time, salary):
        Staff.__init__(self, name, surname, work, working_time, salary)

        self.salary = salary
        self.obj_salary = Salary_cleaner(salary)

    def total_salary(self):
        return (self.salary * 12)

    def getMaidName(self):
        return self.name

    def getMaidSurname(self):
        return self.surname

    def getMaidWork(self):
        return self.work

    def getMaidWorking_time(self):
        return self.working_time

    def getMaidSalary(self):
        return self.salary