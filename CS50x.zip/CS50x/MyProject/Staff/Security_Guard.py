from Staff import Staff
from Staff.Salary import Salary_cleaner

class Security_Guard(Staff):

    def __init__(self, name, surname, work, working_time, salary):
        Staff.__init__(self, name, surname, work, working_time, salary)

        self.salary = salary
        self.obj_salary = Salary_cleaner(salary)

    def total_salary(self):
        return (self.salary * 12)


    def getSecurity_GuardName(self):
        return self.name

    def getSecurity_GuardSurname(self):
        return self.surname

    def getSecurity_GuardWork(self):
        return self.work

    def getSecurity_GuardWorking_time(self):
        return self.working_time

    def getSecurity_GuardSalary(self):
        return self.salary
