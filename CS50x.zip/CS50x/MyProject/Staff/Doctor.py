from Staff.Staff import Staff
from Staff.Salary import Salary_cleaner

class Doctor(Staff):

    def __init__(self, name, surname, work, working_time, salary):
        Staff.__init__(self, name, surname, work, working_time, salary)

        self.salary = salary
        self.obj_salary = Salary_cleaner(salary)

    def total_salary(self):
        return (self.salary * 12)


    def getDoctorName(self):
        return self.name

    def getDoctorSurname(self):
        return self.surname

    def getDoctorWork(self):
        return self.work

    def getDoctorWorking_time(self):
        return self.working_time

    def getDoctorSalary(self):
        return self.salary

d = Doctor("gd","gd", "hjds", 5, 366)
print(d.total_salary())

d.getDoctorSalary()
