from Hospital_department import Department

class Surgical(Department):
    def __init__(self, name, location):
        Department.__init__(self, name, location)

    def surgicalOpareted(self):

        print("""
            If the illness is in the head area = 1 click
            If the illness is in the body area = 2 click
            If the illness is in the foot area = 3 click

        """)
        a = int(input())

        if a == 1:
            print("The patient's head area should be operated on")

        elif a == 2:
            print("The patient's body area should be operated on")

        elif a == 3:
            print("The patient's foot area should be operated on")

