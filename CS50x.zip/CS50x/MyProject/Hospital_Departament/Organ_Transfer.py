from Hospital_department import Department

class Organ_Transfer(Department):
    def __init__(self, name, location):
        Department.__init__(self, name, location)

    # def orqan_satisi(self):


    def orqan(self, boyrek, ag_ciyer, qara_ciyer):
        self.boyrek = boyrek
        self.ag_ciyer = ag_ciyer
        self.qara_ciyer = qara_ciyer

        print("""
        The patient's painful organ        
            1. Boyrek = 1 click
            2. Ag_Ciyer = 2 click
            3. Qara_Ciyer = 3 click
        """)
        o = int(input("Enter the patient's painful organ "))

        if o == 1:
            print("You need a boyrek transfer")

        elif o == 2:
            print("You need a ag ciyer transfer")

        elif o == 3:
            print("You need a qara ciyer transfer")

        else:
            print("Otherwise you will die")
