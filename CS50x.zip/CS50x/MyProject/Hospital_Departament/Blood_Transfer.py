from Hospital_Departament.Hospital_department import Department

class Blood_Transfer(Department):

    def __init__(self, name, location,salary):
        Department.__init__(self, name, location)
        self.salary = salary

    def ageType(self):
        y = int(input("Enter your age : "))

        if y >= 18:
            print("You can donate blood, please have your blood tested")

            # a = None

            try:
                a = input("Enter your blood type : ")
            except:
                print("Incorrect information")

            if a == "+I":
                print("Your blood type is +I")

            elif a == "-I":
                print("Your blood type is -I")

            elif a == "+II":
                print("Your blood type is +II")

            elif a == "-II":
                print("Your blood type is -II")

            elif a == "+III":
                print("Your blood type is +III")

            elif a == "-III":
                print("Your blood type is -III")

            elif a == "+IV":
                print("Your blood type is +IV")

            elif a == "-IV":
                print("Your blood type is -IV")

        else:
            print("You can't donate blood ")
            print("Stopped...")

    def bloodDonate(self):

        print("""
        Who you donated blood to : 
            1. Close patient = 1 click
            2. Forgive blood = 2 click
        """)
        a = int(input("Enter who you donated blood to : "))

        if a == 1:
            print("Go to the blood donation room")

        elif a == 2:
            print("Go to the blood donation room")

        else:
            print("Incorrect Information")


    def bloodQuantity(self):

        print("""
        The amount of blood donation
        1. Norm = 1 click
        2. Not Norm = 2 click
        """)
        a = int(input("The amount of blood donation : "))

        if a == 1 :
            print("The donor must donate 600 g of blood")

        elif a == 2:
            print("The donor can donate between 400 and 800 blood")

        else:
            print("Incorrect information")

    def getSalePrice(self):
        return self.salary

    def setSalePrice(self, salary):
        self.salary = salary

