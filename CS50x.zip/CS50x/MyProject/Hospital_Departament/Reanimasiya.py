from Hospital_Departament.Hospital_department import  Department
class Reanmasiya(Department):
    def __init__(self, name, location):
        Department.__init__(self, name, location)

    def patientCondition(self):

        print("""
            Patient's condition is good = 1 click
            Patient's condition isn't good = 2 click

        """)
        a = int(input("Patient's condition"))

        if a == 1:
            print("The patient is transferred to the ward")

        elif a == 2:
            print("The patient must stay resuscitated for a while")

        else:
            print("Incorrect Information")