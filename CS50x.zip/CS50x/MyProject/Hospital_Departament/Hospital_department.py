class Department:
    def __init__(self,name, location):
        self.name = name
        self.location = location

    def chooseDepartament(self):

        print("""
            Choose Departament :
            1. Reanmasiya = 1 click
            2. Surgical = 2 click
            3. Blood_Transfer = 3 click
            4. Organ_Transfer = 4 click 
        """)

        c = int(input("Choose Departament : "))

        if c == 1:
            print("Reanmasiya")

        elif c == 2:
            print("Surgical")

        elif c == 3:
            print("Blood_Transfer")

        elif c == 4:
            print("Organ_Transfer")

        else:
            print("Incorrect choose")






