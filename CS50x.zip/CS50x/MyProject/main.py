import Patient
from Hospital import Hospital1
from Hospital import State_Hospital
from Vaccinated import Vaccinated
from Vaccinated import Covid_Vaccinated
import Registration
from Room import Room
from Room import Checked_room
from Room import Surgery_room
from Insurance import Insurance
from Insurance import Patient_Insurance
from Hospital_Departament import Hospital_department
from Hospital_Departament import Blood_Transfer
from Surgery import Surgery
from Surgery import Blood_Transfer1
from Hospital_Departament import Reanimasiya
from Staff import Staff
from Staff import Doctor
from Staff import Nurses
from Room import Patient_room




p = Patient.Patient("Nurlan", "Abdullayev", 20, "Male")

h = Hospital1.Hospital()
h.chooseHospital()

s = State_Hospital.State_Hospital("Milan Hospital", "Baki, Nerimanov rayonu", "300 Person", "State Hospital", "500 Room", "Enterance is free")
s.checkVaccin()

v = Vaccinated.Vaccinated()
v.chooseVaccin()

cv = Covid_Vaccinated.Covid_Vaccinated("Sinovac", "0.5 gram", 1, 19)
cv.covidVaccinated_age()
cv.chechealthstatus()

s.hospitalIntroduction()

r = Registration.Registration("Nurlan", "Abdullayev", 20)
print(r.getName())
print(r.getSurname())
print(r.getAge())
r.dataChecked()

rm = Room.Room("room 302", "floor 3")
rm.chooseRoom()
cr = Checked_room.Checked_room("Checked room", "floor 3")
cr.checkedRoom()


i = Insurance.Insurance("man", "yourself")

pi = Patient_Insurance.Patient_Insurance("Nurlan", "Abdullayev", 20, 200)
pi.patientInsurance()


d = Hospital_department.Department("Departament", "floor 4")
d.chooseDepartament()
bd = Blood_Transfer.Blood_Transfer("Blood Departament", "floor 4", 50)
bd.ageType()
print(bd.getSalePrice())
bd.setSalePrice(0)
print(bd.getSalePrice())


rm = Surgery_room.Surgery_room("Surgery room", "floor 3")
rm.surgeryRoom()


s = Surgery.Surgery()
s.chooseSurgary()

bs = Blood_Transfer1.Blood_Transfer1("Blood Transfer", "2 hours")
bs.bloodSurgery()



rd = Reanimasiya.Reanmasiya("Reanmasi Departament", "floor 4")
rd.patientCondition()


st = Staff.Staff()
st.chooseStaff()

std = Doctor.Doctor("Ali", "Mammadyarov", "Doctor", "1-5 day", 3000)
print(std.getDoctorName())
print(std.getDoctorSurname())
print(std.getDoctorWorking_time())

st.chooseStaff()

stn = Nurses.Nurses("Nuray", "Akbarova", "Nurse", "1-5 day", 1000)
print(stn.getNursesName())
print(stn.getNursesSurname())
print(stn.getNursesWorking_time())

rd.patientCondition()


pr = Patient_room.Patient_room("Patient room", "floor 3")
pr.patientRoom()

p.patient_condition()


# The End



