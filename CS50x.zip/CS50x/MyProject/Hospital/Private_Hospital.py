from Hospital1 import Hospital

class Private_Hospital(Hospital):

    def __init__(self, hospital_name, hospital_location, hospital_staff, hospital_type, hospital_room, hospital_enterance):
        Hospital.__init__(self, hospital_name, hospital_location, hospital_staff, hospital_type, hospital_room, hospital_enterance)

    def checkVaccin(self):

        print("""
            You have been vaccinated :
            1. Yes = 1 click
            2. No = 2 click
        """)

        v = int(input("You have been vaccinated : "))

        if v == 1:
            print("You can enter")

        elif v == 2:
            print("You must be vaccinated to enter the hospital")

        else:
            print("Incorrect Information")



    def hospitalIntroduction(self):

        s = int(input("Enter your reason for coming : "))
        print("""
                Your reason for coming : 

                1. Checkup - 1 click
                2. Patient visit  - 2 click
        """)

        if s == 1:
            print("You have to pay 100 azn")

            d = int(input("Payment : "))

            if d == 1:
                print("You can be examined...")

            else:
                print("You cannot be examined in this hospital...")

        elif s == 2:
            print("Approach the registration")

        else:
            print("You cannot enter the hospital for other reasons")