from Hospital1 import Hospital

class Military_Hospital(Hospital):

    def __init__(self, hospital_name, hospital_location, hospital_staff, hospital_type, hospital_room, hospital_enterance):
        self.__hospital_name = hospital_name
        self.__hospital_location = hospital_location
        self.__hospital_staff = hospital_staff
        self.__hospital_type = hospital_type
        self.__hospital_room = hospital_room
        self.__hospital_enterance = hospital_enterance

        # Hospital.__init__(self, hospital_name, hospital_location, hospital_staff, hospital_type, hospital_room, hospital_enterance)

    def getHospitalName(self):
        return self.__hospital_name

    def getHospitalLocation(self):
        return self.__hospital_location

    def getHospitalStaff(self):
        return self.__hospital_staff

    def getHospitalType(self):
        return self.__hospital_type

    def getHospitalRoom(self):
        return self.__hospital_room

    def getHospitalenterance(self):
        return self.__hospital_enterance


    def checkVaccin(self):

        print("""
            You have been vaccinated :
            1. Yes = 1 click
            2. No = 2 click
        """)

        v = int(input("You have been vaccinated : "))

        if v == 1:
            print("You can enter")

        elif v == 2:
            print("You must be vaccinated to enter the hospital")

        else:
            print("Incorrect Information")


    def hospitalIntroduction(self):

        print("Only soldiers and their families can enter: ")
        print(""" 
                1. Soldier  - 1 click
                2. Soldier's family  - 2 click

        """)

        m = int(input("Enter who you are : "))

        if m == 1:
            print("Please provide your identity")
            print("Please wait while your information is being verified...")

            print("""
                      The information is consistent - 1 click
                        """)
            k = int(input())


            if k == 1:
                print("You can enter")

            else:
                print("You can enter")

        elif m == 2:
            print("Please provide your identity")
            print("Please wait while your information is being verified...")

            print("""
                     The information is consistent - 1 click
                              """)
            s = int(input())


            if s == 1:
                print("You can enter")

            else:
                print("You can't enter")

        else:
            print("Incorrect information")

