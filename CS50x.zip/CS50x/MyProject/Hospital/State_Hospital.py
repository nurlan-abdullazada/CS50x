from Hospital.Hospital1 import Hospital

class State_Hospital(Hospital):

    print("Welcome ! ")

    def __init__(self, hospital_name, hospital_location, hospital_staff, hospital_type, hospital_room, hospital_enterance):
        Hospital.__init__(self,hospital_name, hospital_location, hospital_staff, hospital_type, hospital_room, hospital_enterance)

        # self.hostpital = Hospital()

    def checkVaccin(self):

        print("""
            You have been vaccinated :
            1. Yes = 1 click
            2. No = 2 click
        """)

        v = int(input("You have been vaccinated : "))

        if v == 1:
            print("     You can enterance")

        elif v == 2:
            print("     You must be vaccinated to enter the hospital")

        else:
            print("     Incorrect Information")

    def hospitalIntroduction(self):

        print("""
                Your reason for coming : 

                1. Checkup - 1 click
                2. Patient visit  - 2 click
                3. Vaccinanted = 3 click
        """)

        s = int(input("Enter your reason for coming : "))

        if s == 1:
            print("     Approach the registration")

        elif s == 2:
            print("     Approach the registration")

        elif s == 3:
            print("     You get close to vaccination")

        else:
            print("You cannot enter the hospital for other reasons")
