from Hospital1 import Hospital

class Crazy_Hospital(Hospital):

    def __init__(self, hospital_name, hospital_location, hospital_staff, hospital_type, hospital_room,
                 hospital_enterance):
        Hospital.__init__(self, hospital_name, hospital_location, hospital_staff, hospital_type, hospital_room,
                          hospital_enterance)

    def checkVaccin(self):

        print("""
            You have been vaccinated :
            1. Yes = 1 click
            2. No = 2 click
        """)

        v = int(input("You have been vaccinated : "))

        if v == 1:
            print("You can enter")

        elif v == 2:
            print("You must be vaccinated to enter the hospital")

        else:
            print("Incorrect Information")

    def hospitalIntroduction(self):

        print("Only relatives of the patient can enter : ")
        a = int(input("Enter your reason for coming : "))
        print("""
                Your reason for coming :  

                1. Patient visit  - 1 click
        """)

        if a == 1:
            print("You can enter")


        else:
            print("You can't enter")