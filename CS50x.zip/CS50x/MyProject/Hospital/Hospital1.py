class Hospital:

    def __init__(self, hospital_name = "Hospital Name : ", hospital_location = "Hospital Location : ", hospital_staff = "Hospital Staff : ", hospital_type = "Hospital Type : ", hospital_room = "Hospital Room : ", hospital_enterance = "Hospital Enterance : "):
        self.hospital_name = hospital_name
        self.hospital_location = hospital_location
        self.hospital_staff = hospital_staff
        self.hospital_type = hospital_type
        self.hospital_room = hospital_room
        self.hospital_enterance = hospital_enterance

    def chooseHospital(self):

        print("""
            Choose Hospital :
            1. State Hospital = 1 click
            2. Military Hospital = 2 click
            3. Crazy Hospital = 3 click
            4. Private Hospital = 4 click
        """)

        c = int(input("Choose Hospital : "))

        if c == 1:
            print("State Hospital")

        elif c == 2:
            print("Military Hospital")

        elif c == 3:
            print("Crazy Hospital")

        elif c == 4:
            print("Private Hospital")

        else:
            print("Incorrect choose")










