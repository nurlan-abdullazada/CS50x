class Registration:

    def __init__(self, patient_name, patient_surname, patient_age):
        self.patient_name = patient_name
        self.patient_surname = patient_surname
        self.patient_age = patient_age


    def getName(self):
        return self.patient_name

    def getSurname(self):
        return self.patient_surname

    def getAge(self):
        return self.patient_age

    def dataChecked(self):

        print("""
            Data is checked :
            1. True = 1 click
            2. Wrong = 2 click
        """)

        d = int(input("Data is checked : "))

        if d == 1:
            print("Data is true")

        elif d == 2:
            print("Data is wrong")

        else:
            print("Incorrect information")
